package edu.caltech.cs2.helpers;

public class NewMe {
    public static int NUM_CALLS = 0;
}
