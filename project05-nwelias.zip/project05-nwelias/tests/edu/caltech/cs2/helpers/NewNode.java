package edu.caltech.cs2.helpers;

public class NewNode {
    public static int LinkedDeque_NUM_CALLS;
    public static int MoveToFrontDictionary_NUM_CALLS;
    public static int BSTDictionary_NUM_CALLS;
    public static int TrieMap_NUM_CALLS;
}
