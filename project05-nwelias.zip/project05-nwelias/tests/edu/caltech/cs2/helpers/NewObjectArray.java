package edu.caltech.cs2.helpers;

public class NewObjectArray {
    public static int NUM_CALLS = 0;
}
