package edu.caltech.cs2.helpers;

public class RuntimeCounter {
    public static int NUM_CALLS = 0;

    public static void inc() {
        NUM_CALLS++;
    }
}
