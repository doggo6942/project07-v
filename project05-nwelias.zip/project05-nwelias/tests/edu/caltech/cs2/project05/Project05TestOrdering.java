package edu.caltech.cs2.project05;

public class Project05TestOrdering {
    public Project05TestOrdering() {
        throw new InstantiationError("Class is only for storing constant variables");
    }

    public static final int classSpecificTestLevel = 0;
    public static final int sanityTestLevel = 1;
    public static final int stressTestLevel = 2;
    public static final int specialTestLevel = 3;
}
